<?php

$server = "127.0.0.1";
$username = "root";
$password = "";
$database = "calender";

$conn = mysqli_connect($server,$username,$password,$database) or die("koneksi gagal");
?>